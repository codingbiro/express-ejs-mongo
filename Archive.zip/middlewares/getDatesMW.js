//Betolti az elerheto orak datumait a db-bol, kilistazza az adatait

module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    };
};