//Betolti az adott profilt a db-bol, kilistazza az adatait

module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    };
};