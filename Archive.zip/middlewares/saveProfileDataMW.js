//Elmenti az adott profil adatait a db-be

module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    };
};