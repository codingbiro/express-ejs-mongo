//Elmenti az adott profil uj naptaresemenyet a db-be

module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    };
};