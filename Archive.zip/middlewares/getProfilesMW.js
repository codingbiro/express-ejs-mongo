//Betolti a profilokat a db-bol, kilistazza a kepeket, leirasokat es oradijakat

module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    };
};