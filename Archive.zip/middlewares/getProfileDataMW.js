//Betolti az adott profil adatait a db-bol, kilistazza az adatait

module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    };
};