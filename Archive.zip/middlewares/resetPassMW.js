//Reseteli a jelszot

module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    };
};